package br.com.omnitrix.imctrix

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.widget.SeekBar
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*
import android.text.TextWatcher
import java.util.*
import br.com.omnitrix.imctrix.*


class MainActivity : AppCompatActivity() {


    fun unmask(s: String):String{
        return s.replace(Regex("[.]"),"").replace(Regex("[m]"),"")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        var isUpdating : Boolean
        var masker = MaskEditUtil()
        txtHeight.addTextChangedListener(masker.mask(txtHeight, "#.##m", seekHeight))

        seekHeight.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {

            override fun onProgressChanged(seekBar: SeekBar, i: Int, b: Boolean) {
                txtHeight.setText("$i")
            }
            override fun onStartTrackingTouch(seekBar: SeekBar) {
                // Do something
                Toast.makeText(applicationContext,"start tracking",Toast.LENGTH_SHORT).show()
            }

            override fun onStopTrackingTouch(seekBar: SeekBar) {
                // Do something
                Toast.makeText(applicationContext,"stop tracking",Toast.LENGTH_SHORT).show()
            }

        })
    }
}
